//
//  AttractionsApp.swift
//  Attractions
//
//  Created by Thiri Htet on 16/08/2025.
//

import SwiftUI

@main
struct AttractionsApp: App {
    var body: some Scene {
        WindowGroup {
            //Initial Screen
            AttractionsView()
        }
    }
}
