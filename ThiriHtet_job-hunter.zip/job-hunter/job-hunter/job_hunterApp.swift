//
//  job_hunterApp.swift
//  job-hunter
//
//  Created by Thiri Htet on 06/09/2025.
//

import SwiftUI

@main
struct job_hunterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
