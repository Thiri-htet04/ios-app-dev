//
//  ViewController.swift
//  Unsplash
//
//  Created by Thiri Htet on 19/07/2025.
//

import UIKit

class ViewController: UIViewController {
    
    var photos: [Photo] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Task{
            await fetchImages()
        }
    }
    
    func fetchImages() async {
            var urlComponents = URLComponents(string: "https://api.unsplash.com/photos")!
            
    
            urlComponents.queryItems = [
                URLQueryItem(name: "page", value: "1"),
                URLQueryItem(name: "per_page", value: "30")
            ]
            
            var request = URLRequest(url: urlComponents.url!)
            
            request.setValue("Client-ID Yt0qe3ACQAQ8Gq4-xfqoValZFi0KZgUJUL-hbkDlrkg", forHTTPHeaderField: "Authorization")
            
            do {
                
                let (data, _) = try await URLSession.shared.data(for: request)
                
            
                let decoder = JSONDecoder()
                let photosResponse = try decoder.decode([Photo].self, from: data)
                
            
                await MainActor.run {
                    self.photos = photosResponse
                    print(self.photos)
                }
                
            } catch {
                print("Error: \(error)")
            }
        }


}
