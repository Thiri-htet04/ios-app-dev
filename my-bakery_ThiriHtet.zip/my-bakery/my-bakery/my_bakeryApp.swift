//
//  my_bakeryApp.swift
//  my-bakery
//
//  Created by Thiri Htet on 23/08/2025.
//

import SwiftUI

@main
struct my_bakeryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
